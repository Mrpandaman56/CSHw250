# Restaurant Kitchen Simulation

C++ project using stack and queue.
