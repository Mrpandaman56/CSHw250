#include "KitchenManager.h"
#include <iostream>

KitchenManager::KitchenManager() {
    currentOrder = nullptr;
    nextOrderID = 1;
}

void KitchenManager::addNewOrder(const std::string& desc, OrderType type) {
    Order newOrder(nextOrderID++, desc, type);
    prepQueue.push(newOrder);
    std::cout << "Order added to prep queue.\n";
}

void KitchenManager::startPreparingNextOrder() {
    if (currentOrder != nullptr) {
        std::cout << "Already preparing an order.\n";
        return;
    }

    if (prepQueue.empty()) {
        std::cout << "Prep queue is empty.\n";
        return;
    }

    currentOrder = new Order(prepQueue.front());
    prepQueue.pop();

    currentOrder->setStatus(OrderStatus::Preparing);

    std::cout << "Now preparing order #" << currentOrder->getId() << ".\n";
}

void KitchenManager::markOrderAsComplete() {
    if (!currentOrder) {
        std::cout << "No order is currently being prepared.\n";
        return;
    }

    currentOrder->setStatus(OrderStatus::Ready);
    completedOrders.push(*currentOrder);

    std::cout << "Order #" << currentOrder->getId() << " marked as READY.\n";

    delete currentOrder;
    currentOrder = nullptr;
}

void KitchenManager::servePickupOrder() {
    if (completedOrders.empty()) {
        std::cout << "No completed orders to serve.\n";
        return;
    }

    Order top = completedOrders.top();
    completedOrders.pop();

    std::cout << "Serving order:\n";
    top.display();
}

void KitchenManager::viewPrepQueue() const {
    if (prepQueue.empty()) {
        std::cout << "Prep queue is empty.\n";
        return;
    }

    std::cout << "\n--- Prep Queue ---\n";

    std::queue<Order> temp = prepQueue;
    while (!temp.empty()) {
        temp.front().display();
        temp.pop();
    }
}

void KitchenManager::viewCompletedStack() const {
    if (completedOrders.empty()) {
        std::cout << "Completed stack is empty.\n";
        return;
    }

    std::stack<Order> temp = completedOrders;
    std::cout << "\n--- Completed Orders (Top First) ---\n";

    while (!temp.empty()) {
        temp.top().display();
        temp.pop();
    }
}
