#ifndef KITCHENMANAGER_H
#define KITCHENMANAGER_H

#include <queue>
#include <stack>
#include "Order.h"

class KitchenManager {
private:
    std::queue<Order> prepQueue;
    std::stack<Order> completedOrders;
    Order* currentOrder;
    int nextOrderID;

public:
    KitchenManager();

    void addNewOrder(const std::string& desc, OrderType type);
    void startPreparingNextOrder();
    void markOrderAsComplete();
    void servePickupOrder();

    void viewPrepQueue() const;
    void viewCompletedStack() const;
};

#endif
