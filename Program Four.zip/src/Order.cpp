#include "Order.h"
#include <iostream>

Order::Order(int id, const std::string& desc, OrderType t)
    : orderId(id), description(desc), type(t), status(OrderStatus::Pending) {}

int Order::getId() const { return orderId; }
std::string Order::getDescription() const { return description; }
OrderType Order::getType() const { return type; }
OrderStatus Order::getStatus() const { return status; }

void Order::setStatus(OrderStatus newStatus) {
    status = newStatus;
}

void Order::display() const {
    std::cout << "[Order #" << orderId << "] "
              << description << " | "
              << ((type == OrderType::DineIn) ? "Dine-In" : "Takeout")
              << " | Status: ";

    switch (status) {
        case OrderStatus::Pending: std::cout << "Pending"; break;
        case OrderStatus::Preparing: std::cout << "Preparing"; break;
        case OrderStatus::Ready: std::cout << "Ready"; break;
        case OrderStatus::Served: std::cout << "Served"; break;
    }
    std::cout << "\n";
}
