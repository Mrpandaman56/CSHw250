#ifndef ORDER_H
#define ORDER_H

#include <string>
#include <iostream>
#include "enums.h"

class Order {
private:
    int orderId;
    std::string description;
    OrderType type;
    OrderStatus status;

public:
    Order(int id, const std::string& desc, OrderType t);

    int getId() const;
    std::string getDescription() const;
    OrderType getType() const;
    OrderStatus getStatus() const;

    void setStatus(OrderStatus newStatus);

    void display() const;
};

#endif
