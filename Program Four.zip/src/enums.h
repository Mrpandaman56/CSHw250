#ifndef ENUMS_H
#define ENUMS_H

enum class OrderType { DineIn, Takeout };
enum class OrderStatus { Pending, Preparing, Ready, Served };

#endif
